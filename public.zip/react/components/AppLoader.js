import React from 'react';
// import PulseLoader from "react-spinners/PulseLoader";

const AppLoader = () => {
  return (
   <div id="preloader">
    <div className="animsition-loading"></div>
  </div>
  );
};

export default AppLoader;